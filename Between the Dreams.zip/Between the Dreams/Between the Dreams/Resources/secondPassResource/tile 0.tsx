<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="tile 0" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="198" columns="18">
 <image source="../../../lab1/Resources/Chapter05/MoveAndControl.png" width="640" height="400"/>
</tileset>
