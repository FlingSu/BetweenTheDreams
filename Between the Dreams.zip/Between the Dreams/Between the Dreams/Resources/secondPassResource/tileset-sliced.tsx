<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="tileset-sliced" tilewidth="16" tileheight="16" tilecount="575" columns="25">
 <image source="tileset-sliced.png" width="400" height="368"/>
</tileset>
