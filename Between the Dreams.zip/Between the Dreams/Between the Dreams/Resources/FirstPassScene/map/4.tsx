<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="4" tilewidth="32" tileheight="32" tilecount="4096" columns="64">
 <image source="45.png" width="2048" height="2048"/>
</tileset>
