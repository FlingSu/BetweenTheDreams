<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="test" tilewidth="32" tileheight="32" tilecount="240" columns="20">
 <grid orientation="orthogonal" width="60" height="6"/>
 <image source="../../../../MyGame2/Resources/Chapter05/MoveAndControl.png" width="640" height="400"/>
</tileset>
