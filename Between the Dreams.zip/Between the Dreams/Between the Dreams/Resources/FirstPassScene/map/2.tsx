<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="2" tilewidth="32" tileheight="32" tilecount="192" columns="16">
 <image source="0.png" width="512" height="384"/>
</tileset>
