<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="3" tilewidth="32" tileheight="32" tilecount="575" columns="25">
 <image source="tileset-sliced1.png" width="800" height="736"/>
</tileset>
