<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="back" tilewidth="32" tileheight="32" tilecount="2448" columns="68">
 <image source="22.jpg" width="2200" height="1170"/>
</tileset>
